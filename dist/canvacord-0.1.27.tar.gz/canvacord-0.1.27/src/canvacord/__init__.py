from .generators import rankcard
from .generators import trigger
from .generators import communism
from .generators import gay
from .generators import jail
from .generators import hitler
from .generators import spank