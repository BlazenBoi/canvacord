from .rankcard import rankcard
from .trigger import trigger
from .communism import communism
from .gay import gay
from .jail import jail
from .hitler import hitler
from .spank import spank
from .tweet import tweet