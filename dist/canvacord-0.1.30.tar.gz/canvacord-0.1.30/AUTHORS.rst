Authors
-------

* Eric (New contributor)
* Anthony 


