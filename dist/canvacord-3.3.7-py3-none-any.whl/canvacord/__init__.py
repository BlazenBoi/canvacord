__version__ = "3.3.7"

from .generators import rankcard
from .generators import trigger
from .generators import communism
from .generators import gay
from .generators import jail
from .generators import hitler
from .generators import spank
from .generators import aborted
from .generators import affect
from .generators import airpods
from .generators import america
from .generators import bed
from .generators import wanted
from .generators import jokeoverhead
from .generators import checkversion
from .generators import avatar