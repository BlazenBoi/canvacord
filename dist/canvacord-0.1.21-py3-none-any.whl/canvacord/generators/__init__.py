from .rankcard import rankcard
from .trigger import trigger
from .communism import communism