from .generators import rankcard
from .generators import trigger
from .generators import communism